# Jayan Sesha Portfolio

A responsive dark portfolio built with HTML, CSS and JavaScript. No installation, framework, API keys or build command required.

## Add to your GitHub repository

1. Unzip the download.
2. Upload `index.html`, `style.css`, `script.js` and the entire `assets` folder to the root of your repository. Keep the folder names and filenames unchanged.
3. Commit the files. The repository root should contain `index.html`, not a nested `portfolio` folder.
4. In your repository, open Settings > Pages. Under Build and deployment, choose Deploy from a branch, select your default branch (usually `main`) and choose `/ (root)`. Save.
5. When GitHub finishes deployment, Pages will show your website URL.

If you're pasting code manually, create the three files named above and copy each file's full contents. Upload the files in `assets` separately. The site uses relative paths, so it also works under a GitHub project URL.

## Preview

Open `index.html` in a browser. All assets are local and work without an internet connection.

## Edit

- `index.html`: introduction, experience, research, leadership and email address.
- `style.css`: colors, spacing, type and responsive layouts. Main colors are at the top.
- `script.js`: mobile navigation and footer year.
- `assets/portrait-000.jpg`: headshot extracted from your uploaded PDF without changing your appearance.
- `assets/Jayan-Sesha-Resume.pdf`: original uploaded resume.

The site includes your email address. The linked original resume includes your phone number. Content is based on your supplied resume; pitch upside figures are labeled as thesis estimates.

No LinkedIn link is included because a verified URL was not supplied. Add one to the contact section when ready.

Validation: JavaScript syntax, document structure, section targets, asset paths and absence of em dashes were checked. Browser rendering was not inspected in this environment. Before publishing, open the site and check a narrow/mobile viewport.
